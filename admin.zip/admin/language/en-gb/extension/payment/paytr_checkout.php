<?php
// Heading
$_['heading_title']                                     = 'PayTR Payment Infrastructure';

// Text
$_['text_payment']                                      = 'Credit Card (Secure Shopping)';
$_['text_success']                                      = 'Success: PayTR payment infrastructure module updated!';
$_['text_edit']                                         = 'Edit';
$_['text_paytr_checkout']                               = '<a href="https://www.paytr.com/" target="_blank"><img src="view/image/payment/paytr.png" alt="paytr" title="paytr"/></a>';

// Entry
$_['text_home']                                         = 'Home';
$_['text_payment']                                      = 'Extensions';
$_['text_paytr']                                        = 'PayTR Payment Infrastructure';

// Button
$_['button_save']                                       = 'Save';
$_['button_cancel']                                     = 'Cancel';

// Error
$_['error_permission']                                  = 'You dont have authorization for this module!';
$_['error_paytr_checkout_merchant_id']                  = '<strong>Merchant ID</strong> must be enter!';
$_['error_paytr_checkout_merchant_id_val']              = '<strong>Merchant ID</strong> must be numeric!';
$_['error_paytr_checkout_merchant_key']                 = '<strong>Merchant Key</strong> must be enter!';
$_['error_paytr_checkout_merchant_key_len']             = '<strong>Merchant Key</strong> length must be 16 character!';
$_['error_paytr_checkout_merchant_salt']                = '<strong>Merchant Salt</strong> must be enter!';
$_['error_paytr_checkout_merchant_salt_len']            = '<strong>Merchant Salt</strong> length must be 16 character!';
$_['error_paytr_checkout_order_status_id']              = 'You have to choose what status will be assigned during the <strong>Payment Process!<strong>';
$_['error_paytr_checkout_order_completed_id']           = 'You have to choose what status will be assigned when the <strong>Payment Approved!<strong>';
$_['error_paytr_checkout_order_canceled_id']            = 'You have to choose what status will be assigned when the <strong>Payment Dont Approved!<strong>';
$_['error_paytr_checkout_order_status_general']         = 'You have to choose <strong> In the payment process<strong>, <strong>If the payment approved<strong>, <strong>If the payment doesnt approved<strong> fields';
$_['error_paytr_checkout_merchant_general']             = 'You have to enter <strong>Merchant ID<strong>,<strong>Merchant Password<strong>, <strong>Merchant Salt<strong> informations.<br/>You can get this information from <strong>INFO<strong> section in the PayTR Merchant Panel.';
$_['error_paytr_checkout_installment_number']           = 'You can edit<strong>Maximum Installment Count <strong>according to your preference';

$_['info_paytr_checkout_merchant_general']              = 'Store information can be found at <a href="https://www.paytr.com/magaza/bilgi
" target="_blank">this address</a>.';

$_['api_information']                                   = 'PayTR Store Information';
$_['information_tab']                                   = '(You can see from the INFORMATION tab of the store panel)';
$_['merchant_id']                                       = 'Merchant ID';
$_['merchant_key']                                      = 'Merchant Key';
$_['merchant_salt']                                     = 'Merchant Salt';
$_['order_status']                                      = 'Order States';
$_['payment_approved']                                  = 'When payment is confirmed';
$_['error_payment_approved']                            = 'What status is assigned to the order when the customer\'s payment is successfully collected?';
$_['payment_notapproved']                               = 'If payment is not approved';
$_['error_payment_notapproved']                         = 'What status is assigned to the order when the customer\'s payment fails?';
$_['module_settings']                                   = 'Module Settings';
$_['module_status']                                     = 'Module Status';
$_['module_language']                                   = 'Module Language Option';
$_['max_installments']                                  = 'Maximum Number of Installments';
$_['please_select']                                     = 'Please select the required field';
$_['category_based']                                    = 'Category Based Installment Settings';
$_['category_based_note']                               = 'When you choose category based option, you must be save first. Then you can set installment options every each category when you\'ll reopen this module.';
$_['notify_status']                                     = 'Notify Customer';
$_['notify_status_note']                                = 'Notify order status to customer via email when order is completed';
$_['notify_enabled']                                    = 'Enabled';
$_['notify_disabled']                                   = 'Disabled';
$_['ins_total_status']                                  = 'Change Total Value';
$_['ins_total']                                         = 'Installment Amount';
$_['ins_total_note']                                    = 'It shows the installment amount on the invoice. It adds the installment amount to the subtotal in the order detail and changes the Total Amount of the Invoice. If you\'re choose Change Total Value, will be change Total Amount of the Invoice.';
$_['order_total']                                       = 'Change Order Total';
$_['order_total_note']                                  = 'When customer paid with installment, change the order total with installment total.';