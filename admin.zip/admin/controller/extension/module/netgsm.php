<?php

class ControllerExtensionModuleNetgsm extends Controller {
	private $error = array();

	public function index()
    {
        $this->load->language("extension/module/netgsm");

        $this->document->setTitle($this->language->get("heading_title"));

        $this->load->model('setting/setting');
        $this->load->model('design/layout');

        if (($this->request->server["REQUEST_METHOD"] == "POST") && $this->validate()) {
            $this->model_setting_setting->editSetting('netgsm', $this->request->post);
            $this->session->data["success"] = $this->language->get("text_success");
            if (isset($this->request->post['sayfayi_yenile']) and $this->request->post['sayfayi_yenile']) {
                $this->response->redirect($this->url->link('extension/module/netgsm', 'token=' . $this->session->data['token'], true));
            } else {
                $this->response->redirect($this->url->link('extension/extension', 'token=' . $this->session->data['token'] . '&type=module', true));
            }
        }

        if (isset($this->error["warning"])) {
            $data["error_warning"] = $this->error["warning"];
        } else {
            $data["error_warning"] = "";
        }

        $data['breadcrumbs'] = array();

        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('text_home'),
            'href' => $this->url->link('common/dashboard', 'token=' . $this->session->data['token'], true),
            'separator' => false
        );

        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('text_extension'),
            'href' => $this->url->link('marketplace/extension', 'token=' . $this->session->data['token'] . '&type=module', true),
            'separator' => ' :: '
        );

        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('heading_title'),
            'href' => $this->url->link('extension/module/netgsm', 'token=' . $this->session->data['token'], true),
            'separator' => ' :: '
        );

        $data['action'] = $this->url->link('extension/module/netgsm', 'token=' . $this->session->data['token'], true);
        $data['cancel'] = $this->url->link('marketplace/extension', 'token=' . $this->session->data['token'] . '&type=module', true);
        $data['token'] = $this->session->data['token'];


        $language= array('heading_title','text_extension','text_success','text_edit','text_enabled','text_disabled',
            'entry_name','entry_title','entry_description','entry_status','error_permission','error_name',
            'entry_user','entry_pass','entry_smsselectfirstitem','entry_newuser_admin_no','entry_newuser_admin_text','entry_newuser_customer_text',
            'entry_neworder_admin_no','entry_neworder_admin_text','entry_neworder_customer_text','entry_order_status_first_item',
            'entry_order_status_change_text','entry_refunded_admin_no','entry_refunded_admin_text','entry_netgsmrehber',
            'entry_loginbtn','entry_savebtn','entry_errorlogin','entry_creditbuy','entry_usevar','entry_smstext','entry_privatesmscontent',
            'entry_privatesmsphone','label_user','label_pass','label_smstitle','label_newuseradmin','label_newusercustomer',
            'label_neworderadmin','label_newordercustomer','label_orderstatus','label_orderrefund','label_rehbertitle','label_trChar','entry_trcharacter', 'about','label_bulkrehber');

        foreach ($language as $item) {
            $data[$item] = $this->language->get($item);
        }

        $dizi = array('netgsm_status','netgsm_turkishChar',
            'netgsm_order_refund_to_admin_control', 'netgsm_order_refund_to_admin_no', 'netgsm_order_refund_to_admin_text',
            'netgsm_neworder_to_customer_text', 'netgsm_neworder_to_customer_control',
            'netgsm_neworder_to_admin_text', 'netgsm_neworder_to_admin_no', 'netgsm_neworder_to_admin_control',
            'netgsm_newuser_to_customer_text', 'netgsm_newuser_to_customer_control',
            'netgsm_newuser_to_admin_text', 'netgsm_newuser_to_admin_no', 'netgsm_newuser_to_admin_control',
            'netgsm_input_smstitle', 'netgsm_pass', 'netgsm_user',
            'netgsm_orderstatus_change_customer_control',
            'netgsm_rehber_control','netgsm_rehber_groupname'
        );
        for ($x = 0; $x < count($dizi); $x++)          //diziye eklediğimiz değişkenlerle  alttaki kodu çoğaltıyoruz.
        {
            if (isset($this->request->post[$dizi[$x]])) {
                $data[$dizi[$x]] = $this->request->post[$dizi[$x]];
            } elseif ($this->config->get($dizi[$x])) {
                $data[$dizi[$x]] = $this->config->get($dizi[$x]);
            } else {
                $data[$dizi[$x]] = '';
            }
        }

        //sipariş durumu değiştiğinde START
        $this->load->model('localisation/order_status');
        $kargo_durumlari = $this->model_localisation_order_status->getOrderStatuses();
        $data['kargo_durumlari'] = $kargo_durumlari;

        foreach ($kargo_durumlari as $kd) {
            if (isset($this->request->post['netgsm_order_status_text_' . $kd['order_status_id']])) {
                $data['netgsm_order_status_text_' . $kd['order_status_id']] = $this->request->post['netgsm_order_status_text_' . $kd['order_status_id']];
            } elseif ($this->config->get('netgsm_order_status_text_' . $kd['order_status_id'])) {
                $data['netgsm_order_status_text_' . $kd['order_status_id']] = $this->config->get('netgsm_order_status_text_' . $kd['order_status_id']);
            } else {
                $data['netgsm_order_status_text_' . $kd['order_status_id']] = '';
            }
        }

        if (empty($data['netgsm_user']) || empty($data['netgsm_pass'])) {
            $data['netgsm_credit'] = '10Sms göndermek ve bakiyenizi görüntüleyebilmek için üyelik bilgilerinizi giriniz.';
            $data['netgsm_package'] = 'Paket ve Kampanyalarınızı görüntüleyebilmek için üyelik bilgilerinizi giriniz.';
            $data['netgsm_smstitle'] = '';
            $data['netgsm_all_title'] = '';
            $data['netgsm_login_status'] = false;
            $data['netgsm_inbox_message'] = 'Gelen kutunuzu görmek için giriş yapmalısınız.';
        } else {
            $netgsmsms = new Netgsmsms($data['netgsm_user'], $data['netgsm_pass']);
            $data['netgsm_credit'] = $netgsmsms->getCredit();
            $data['netgsm_smstitle'] = $this->config->get('netgsm_input_smstitle');
            $data['netgsm_all_smstitle'] = $netgsmsms->getHeaders();
            $data['netgsm_package'] = $netgsmsms->getAsset();
            $inboxs = $netgsmsms->inbox();
            $inbox_data = [];
            $tmp = [];
            $data['netgsm_inbox_status'] = $inboxs['status'];
            if (isset($inboxs['status']) && $inboxs['status']==200){
                unset($inboxs['status']);
                foreach ($inboxs as $key => $inbox){
                    if ($key>250){break;}
                    if (isset($inbox['phone']) && !empty($inbox['phone'])){
                        $customer = $this->getCustomerByPhone($inbox['phone']);
                        if ($customer != null){
                            $tmp['id'] = $customer['customer_id'] ;
                            $tmp['firstname'] = $customer['firstname'] ;
                            $tmp['lastname'] = $customer['lastname'] ;
                            $tmp['name'] = $customer['firstname'] .' '. $customer['lastname'] ;
                            $tmp['email'] = $customer['email'];
                        } else {
                            $tmp['id'] = '' ;
                            $tmp['name'] = '' ;
                            $tmp['email'] = '';
                        }

                        $tmp['phone'] =$inbox['phone'];
                        $tmp['msg'] =$inbox['message'];
                        $datetime = explode(' ',$inbox['time']);
                        $tmp['date'] =$datetime[0];
                        $tmp['time'] =$datetime[1];
                        array_push($inbox_data,$tmp);
                    }
                }
            } else {
                $data['netgsm_inbox_message'] = $inboxs['message'];
            }
            $data['netgsm_inbox'] = $inbox_data;

            $data['netgsm_login_status'] = true;
        }

        $this->document->addStyle('view/javascript/netgsm/lib/sweetalert2/dist/sweetalert2.css');
        $this->document->addScript('view/javascript/netgsm/lib/sweetalert2/dist/sweetalert2.all.min.js');

        $data["header"] = $this->load->controller("common/header");
		$data["column_left"] = $this->load->controller("common/column_left");
		$data["footer"] = $this->load->controller("common/footer");

		$this->response->setOutput($this->load->view("extension/module/netgsm", $data));
	}

    protected function validate() {
        if (!$this->user->hasPermission('modify', 'extension/module/netgsm')) {
            $this->error['warning'] = $this->language->get('error_permission');
        }
        return !$this->error;
    }

    /*
     * 1:n SMS gönderimi
     */
    public function sendSMS()
    {
        $json = array();
        $netgsm_user = $this->config->get('netgsm_user');
        $netgsm_pass = $this->config->get('netgsm_pass');
        $netgsm_title = $this->config->get('netgsm_input_smstitle');
        $netgsm_trchar = $this->config->get('netgsm_turkishChar');

        if(isset($this->request->post['message'])){
            $phones = $this->request->post['phone'];
            $message = $this->request->post['message'];
            if($phones != ''){
                $netgsmsms = new Netgsmsms($netgsm_user, $netgsm_pass, $netgsm_title, $netgsm_trchar);
                $result = $netgsmsms->sendSMS($phones, $message);
                $array = explode(' ',$result);
                if($array[0]=='00')
                {
                    $json['result'] = 'success';
                    $json['resultmsg'] = 'Sms gönderimi başarılı oldu!';
                }
                else{
                    $json['result'] = 'error';
                    $json['resultmsg'] = 'Sms gönderimi başarısız oldu. Lütfen Netgsm hesabınıza giriş yaptığınıza ve başlık seçtiğinize emin olun.' ;
                }
            } else {
                $json['result'] = 'error';
                $json['resultmsg'] = 'Telefon numarası bulunamadı.';
            }

        } else {
            $json['result'] = 'error';
            $json['resultmsg'] = 'Sms gönderimi başarısız.';
        }
        $this->response->setOutput(json_encode($json));
    }

    /*
     * Gelen SMS ve Gelen çağrı sms cevaplama fonksiyonu.   1:n
     */
    public function sendSMSinbox()
    {
        $id = $this->request->post['id'];
        $phone = $this->request->post['phone'];
        $json = array();
        if(isset($this->request->post['message'])){
            $message = $this->request->post['message'];
            $netgsm_user = $this->config->get('netgsm_user');
            $netgsm_pass = $this->config->get('netgsm_pass');
            $netgsm_title = $this->config->get('netgsm_input_smstitle');
            $netgsm_trchar = $this->config->get('netgsm_turkishChar');

            if($phone != ''){
                $netgsmsms = new Netgsmsms($netgsm_user, $netgsm_pass, $netgsm_title, $netgsm_trchar);
                if ($id!=''){
                    $sendMessageText = $this->getCustomerReplaceMessage($id, $message);
                } else {
                    $sendMessageText = $message;
                }
                $result = $netgsmsms->sendSMS($phone, $sendMessageText);

                $array = explode(' ',$result);
                if($array[0]=='00')
                {
                    $json['result'] = 'success';
                    $json['resultmsg'] = 'Sms gönderimi başarılı.';
                }
                else{
                    $json['result'] = 'error';
                    $json['resultmsg'] = 'Sms gönderimi başarısız. Lütfen Netgsm hesabınıza giriş yaptığınıza ve başlık seçtiğinize emin olun.' ;
                }
            } else {
                $json['result'] = 'error';
                $json['resultmsg'] = 'Telefon numarası bulunamadı.';
            }
        }
        else
        {
            $json['result'] = 'error';
            $json['resultmsg'] = 'Sms gönderimi başarısız.';
        }
        $this->response->setOutput(json_encode($json));
    }

    /*
     * Müşteriler ve Siparişler sayfalarından gönderilen toplu smsler.  n:n
     */
    public function sendSMSBulk()
    {
        $json = array();
        if(isset($this->request->post['message'])){
            $message = $this->request->post['message'];
            $netgsm_user = $this->config->get('netgsm_user');
            $netgsm_pass = $this->config->get('netgsm_pass');
            $netgsm_title = $this->config->get('netgsm_input_smstitle');
            $netgsm_trchar = $this->config->get('netgsm_turkishChar');

            if(isset($this->request->post['phone']) && $this->request->post['phone'] != '' && isset($this->request->post['ids']) and $this->request->post['ids'] != '') {
                $netgsmsms = new Netgsmsms($netgsm_user, $netgsm_pass, $netgsm_title, $netgsm_trchar);
                $phones = explode(',', $this->request->post['phone']);
                $itemIds = explode(',', $this->request->post['ids']);
                $phoneandMessage = '';

                if(isset($this->request->post['smstype'])){
                    $smstype = $this->request->post['smstype'];
                    foreach ($itemIds as $key => $id) {
                        if ($phones[$key] != '') {
                            if ($smstype == 1) {    //Müşteri listesi
                                $phoneandMessage .= '<mp><msg><![CDATA[' . $this->getCustomerReplaceMessage($id, $message) . ']]></msg><no>' . $netgsmsms->getphoneClear($phones[$key]) . '</no></mp>' . "\n";
                            } else if ($smstype == 2) {    //Sipariş listesi
                                $phoneandMessage .= '<mp><msg><![CDATA[' . $this->convertorders($id, $message) . ']]></msg><no>' . $netgsmsms->getphoneClear($phones[$key]) . '</no></mp>' . "\n";
                            }
                        }
                    }
                    $result = $netgsmsms->sendSMS_NtoN($phoneandMessage);
                    $array = explode(' ', $result);

                    if ($array[0] == '00') {
                        $json['result'] = 'success';
                        $json['resultmsg'] = 'Smsler başarılı bir şekilde gönderildi.';
                    } else {
                        $json['result'] = 'error';
                        $json['resultmsg'] = 'Sms gönderimi başarısız. Lütfen Netgsm hesabınıza giriş yaptığınıza ve başlık seçtiğinize emin olun.';
                    }
                } else {
                    $json['result'] = 'error';
                    $json['resultmsg'] = 'Sms gönderimi başarısız. Müşteriler veya siparişler sayfasından toplu SMS gönderebilirsiniz.';
                }
            } else {
                $json['result'] = 'error';
                $json['resultmsg'] = 'Telefon numarası bulunamadı.';
            }
        } else {
            $json['result'] = 'error';
            $json['resultmsg'] = 'Sms gönderimi başarısız.';
        }
        $this->response->setOutput(json_encode($json));
    }

    /*
     *  Sipariş ID bilgisinden müşteriyi bulur ve gönderilecek SMSi özelleştirir.
     */
    private function convertorders($id, $data)
    {
        $this->load->model('sale/order');
        $order = $this->model_sale_order->getOrder($id);

        $unwanted= array('[müşteri]', '[sipariş_no]', '[kargo]', '[toplam]', '[siparişdurumu]');
        $replace = array  ($order['customer'], $order['order_id'], $order['shipping_code'], $order['total'], $order['order_status']);
        $result = str_replace($unwanted, $replace, $data);
        return $result;
    }

    /*
     *  Müşteri ID bilgisinden müşteriyi bulur ve gönderilecek SMSi özelleştirir.
     */
    private function getCustomerReplaceMessage($id, $data)
    {
        $this->load->model('customer/customer');
        $customer = $this->model_customer_customer->getCustomer($id);

        $unwanted = array('[uye_adi]','[uye_soyadi]','[uye_telefonu]', '[uye_epostasi]');
        $replace = array  ($customer['firstname'] ,$customer['lastname'], $customer['telephone'], $customer['email']);
        $result = str_replace($unwanted, $replace, $data);
        return $result;
    }

    /*
     * Telefon numarası ile müşteriyi bulur
     */
    public function getCustomerByPhone($phone) {
        $query = $this->db->query("SELECT * FROM " . DB_PREFIX . "customer WHERE LOWER(telephone) like '%" . $this->db->escape(utf8_strtolower($phone)) . "%'");

        return $query->row;
    }

    /*
     * Opencart müşterilerini Netgsm rehberine aktarır
     */
    public function rehberAktar()
    {
        $this->load->model('customer/customer');
        $results = $this->model_customer_customer->getCustomers();

        $contacts = []; $tmp = [];
        foreach ($results as $result) {
            $tmp['firstname'] = $result['firstname'];
            $tmp['lastname'] = $result['lastname'];
            $tmp['telephone'] = $result['telephone'];
            array_push($contacts, $tmp);
        }

        $netgsmsms = new Netgsmsms($this->config->get('netgsm_user'),$this->config->get('netgsm_pass'),'',$this->config->get('netgsm_turkishChar'));
        $groupName = 'Opencart';
        if(isset($this->request->post['groupName'])){
            $groupName = $this->request->post['groupName'];
        }
        $moving = $netgsmsms->setContact($contacts, $groupName);

        $json = ['result'=>'success','resultmsg'=>'Toplam <b>'.count($contacts).'</b> müşteri <b>'.$groupName.'</b> grubuna aktarıldı.'];
        $this->response->setOutput(json_encode($json));
    }

    /*
     * Netsantral ve ses sekmesi verilerini çeker. Netsantral e bakar yoksa Sabit telefon u sorgular
     */
    public function getNetsantralReport()
    {
        $netgsmsms = new Netgsmsms($this->config->get('netgsm_user'),$this->config->get('netgsm_pass'),'',$this->config->get('netgsm_turkishChar'));
        $json = $netgsmsms->getVoipReport();
        $type = 'NETSANTRAL';
        $info = '';
        $table = '<table  data-pagination="true" id="table" name="table" class="table table-bordered table-striped dataTable no-footer"
                            data-search="true" data-search-align="left"
                            data-pagination-v-align="bottom"
                            data-click-to-select="true"
                            data-toggle="table"
                            data-page-list="[10, 25, 50, 100, 150, 200]"><thead><th>#</th><th>Tarih</th><th>Arayan</th><th>Aranan</th><th>Süre</th><th>Yön</th><th>İşlemler</th></thead><tbody>';
        $object = json_decode($json);
        if (is_object($object) && isset($object->success)){
            foreach ($object->data as $key => $data) {
                if ($key>250){break;}
                $table .= '<tr>';
                $table .= '<td>'.$data->call_id.'</td>';
                $table .= '<td>'.$data->date.'</td>';

                $customer = $this->getCustomerByPhone(ltrim($data->caller_number,'0'));
                $c_id = '';
                $c_name = '';
                if ($customer != null) {
                    $c_id = $customer['customer_id'];
                    $c_name = $customer['firstname']. ' ' . $customer['lastname'] ;
                }

                if($c_name != ''){
                    $table .= '<td><i class="fa fa-user" style="color:#06B7F0"></i> <a href="index.php?route=customer/customer/edit&token='.$this->session->data['token'].'&customer_id='.$c_id.'" target="_blank" data-toggle="tooltip" data-placement="top" title="'.$data->caller_number.'">'.$c_name.'</a></td>';
                } else {
                    $table .= '<td>'.$data->caller_number.'</td>';
                }

                $table .= '<td>'.$data->dial_number.'</td>';
                $table .= '<td>'.$data->time.'</td>';

                $direction = '';
                switch ($data->direction){
                    case 0: //giden
                        $direction = '<i class="fa fa-arrow-circle-o-up" style="color: #3498DB;"></i> Giden';
                        break;
                    case 1:
                        $direction = '<i class="fa fa-arrow-circle-down" style="color: #2ECC71;"></i> Gelen';
                        break;
                    case 2:
                        $direction = '<i class="fa fa-arrow-circle-down" style="color: #E74C3C;"></i> Gelen Cevapsız';
                        break;
                    case 3:
                        $direction = '<i class="fa fa-arrow-circle-up" style="color: #E74C3C;"></i> Giden Cevapsız';
                        break;
                    case 4:
                        break;
                        $direction = '<i class="fa fa-arrow-circle-left" style="color: #2C3E50;"></i> <i class="fa fa-arrow-circle-right" style="color: #2C3E50;"></i> İç Arama';
                    case 5:
                        break;
                        $direction = '<i class="fa fa-arrow-circle-left" style="color: #E74C3C;"></i> <i class="fa fa-arrow-circle-right" style="color: #E74C3C;"></i> İç Cevapsız Arama';
                    default:
                        $direction = 'Bilinmiyor';
                        break;
                }
                $table .= '<td>'. $direction .'</td>';
                if (strlen($data->caller_number )==11){
                    $table .= '<td><a href="javascript:void(0);" class="btn btn-info btn-sm" onclick="netgsm_sendSMS_bulkTab(\''.$c_id.'\',\''.$data->caller_number.'\'); ">Arayana SMS Gönder</a></td>';
                } else {
                    $table .= '<td></td>';
                }
                $table .= '</tr>';
            }
            $table .= '</tbody></table>';
            $message = $table;
            $status = 'success';
            $type = 'NETSANTRAL';
            $info = $object->success->message;
        } else {
            if (is_object($object) && isset($object->error)) {
                if (in_array($object->error->code, [30, 80])) {
                    $json = $netgsmsms->getPhoneReport();

                    $table = '<table  data-pagination="true" id="table" name="table" class="table table-bordered table-striped dataTable no-footer"
                            data-search="true" data-search-align="left"
                            data-pagination-v-align="bottom"
                            data-click-to-select="true"
                            data-toggle="table"
                            data-page-list="[10, 25, 50, 100, 150, 200]"><thead><th>#</th><th>Tarih</th><th>Arayan</th><th>Süre</th><th>Yön</th><th>İşlemler</th></thead><tbody>';
                    $object = json_decode($json);
                    if (is_object($object) && isset($object->success)) {
                        foreach ($object->data as $key=>$data) {
                            if ($key>250){break;}
                            $table .= '<tr>';
                            $table .= '<td>#</td>';
                            $table .= '<td>' . $data->date . '</td>';

                            $customer = $this->getCustomerByPhone(ltrim($data->caller_number,'0'));
                            $c_id = '';
                            $c_name = '';
                            if ($customer != null) {
                                $c_id = $customer['customer_id'];
                                $c_name = $customer['firstname'] . ' ' . $customer['lastname'];
                            }

                            if ($c_name != '') {
                                $table .= '<td><i class="fa fa-user" style="color:#06B7F0"></i> <a href="index.php?route=customer/customer/edit&token=' . $this->session->data['token'] . '&customer_id=' . $c_id . '" target="_blank" data-toggle="tooltip" data-placement="top" title="' . $data->caller_number . '">' . $c_name . '</a></td>';
                            } else {
                                $table .= '<td>' . $data->caller_number . '</td>';
                            }

                            $table .= '<td>' . $data->time . '</td>';
                            switch ($data->direction) {
                                case 1:
                                    $direction = '<i class="fa fa-arrow-circle-down" style="color: #2ECC71;"></i> Gelen';
                                    break;
                                case 2: //giden
                                    $direction = '<i class="fa fa-arrow-circle-o-up" style="color: #3498DB;"></i> Giden';
                                    break;
                                case 3:
                                    $direction = '<i class="fa fa-arrow-circle-down" style="color: #E74C3C;"></i> Cevapsız';
                                    break;
                                default:
                                    $direction = 'Bilinmiyor';
                                    break;
                            }
                            $table .= '<td>' . $direction . '</td>';
                            if (in_array(strlen($data->caller_number), [10,11])) {
                                $table .= '<td><a href="javascript:void(0);" class="btn btn-info btn-sm" onclick="netgsm_sendSMS_bulkTab(\'' . $c_id . '\',\'' . $data->caller_number . '\'); ">Arayana SMS Gönder</a></td>';
                            } else {
                                $table .= '<td></td>';
                            }
                            $table .= '</tr>';
                        }
                        $table .= '</tbody></table>';
                        $message = $table;
                        $status = 'success';
                        $type = 'SES';
                        $info = $object->success->message;
                    } else {
                        if (is_object($object) && isset($object->error)) {
                            $status = 'error';
                            $message = $object->error->message;
                            $info = $object->error->message;
                        } else {
                            $message = 'Bilinmeyen Hata oluştu.';
                            $info = 'Bilinmeyen Hata oluştu.';
                            $status = 'error';
                        }
                    }
                } else {
                    $status = 'error';
                    $message = $object->error->message;
                    $info = $object->error->message;
                }
            } else {
                $message = 'Bilinmeyen Hata oluştu.';
                $info = 'Bilinmeyen Hata oluştu.';
                $status = 'error';
            }
        }
        $this->response->setOutput(json_encode(['status'=>$status, 'message'=>$message, 'type'=>$type, 'info'=>$info]));
    }

}