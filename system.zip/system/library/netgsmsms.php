<?php

class Netgsmsms
{
    private $usercode;
    private $password;
    private $header;
    private $language = '';

    public function __construct($usercode, $password, $header='', $trChar = '')
    {
        error_reporting(0);
        $this->usercode = $usercode;
        $this->password = $password;
        $this->header = $header;

        $this->language = '';
        if ($trChar == 1){
            $this->language = "dil='TR'";
        }
    }

    /*
     * 1:n SMS gönderme fonksiyonudur.
     */
    public function sendSMS($phoneDatas, $message)
    {
        $phones = explode(',', $phoneDatas);
        $sendPhones = '';
        foreach ($phones as $phone){
            if($phone != ''){
                $sendPhones.='<no>'. $this->getphoneClear($phone) .'</no>';
            }
        }

        $requestUrl = 'https://api.netgsm.com.tr/sms/send/xml';
        $xml='<?xml version="1.0" encoding="UTF-8"?>
                <mainbody>
	                <header>
		                <company opcrd="1" '.$this->language.' >NETGSM</company>
                        <usercode>'.$this->usercode.'</usercode>
                        <password>'.$this->password.'</password>
		                <startdate></startdate>
		                <stopdate></stopdate>
	                    <type>1:n</type>
                        <msgheader>'.$this->header.'</msgheader>
                    </header>
		            <body>
		                <msg><![CDATA['.$message.']]></msg>'
                            . $sendPhones . '
		            </body>
                </mainbody>';
        return $this->XMLPOST($requestUrl, $xml);
    }

    /*
     * n:n SMS gönderme fonksiyonudur.
     */
    public function sendSMS_NtoN($message)
    {
        $requestUrl = 'https://api.netgsm.com.tr/sms/send/xml';
        $xml = '<?xml version="1.0" encoding="UTF-8"?>
                    <mainbody>
                        <header>
                            <company opcrd="1" '.$this->language.'>Netgsm</company>
                            <usercode>'.$this->usercode.'</usercode>
                            <password>'.$this->password.'</password>
                            <startdate></startdate>
                            <stopdate></stopdate>
                            <type>n:n</type>
                            <msgheader>'.$this->header.'</msgheader>
                        </header>
                        <body>
                            '. $message .'
                        </body>
                    </mainbody>';
        return $this->XMLPOST($requestUrl,$xml);
    }

    /*
     * Başlıkları listeler
     */
    public function getHeaders(){
        $requestUrl = 'https://api.netgsm.com.tr/get_msgheader.asp?usercode='.$this->usercode.'&password='.$this->password;
        $result = $this->XMLPOST($requestUrl,'');
        return $this->getHeaderResult($result);
    }

    /*
     * Gelen SMS listesini çeker.
     */
    public function inbox(){
        $xml = '<?xml version="1.0"?>
                    <mainbody>
                        <header>
                            <company>Netgsm</company>
                            <usercode>'.$this->usercode.'</usercode>
                            <password>'.$this->password.'</password>
                            <startdate>'.date('dmYHi', time() - 60*60*24*30).'</startdate>
                            <stopdate>'.date('dmYHi', time() + 60*60*24+60).'</stopdate>
                            <type>0</type>
                        </header>
                    </mainbody>';
        $response = $this->XMLPOST( 'https://api.netgsm.com.tr/sms/receive/xml', $xml );
        return $this->inboxResponse($response);
    }

    /*
     * GElen kutusu sonuçlarını yorumlar
     */
    private function inboxResponse($data){
        $result = array();
        $result['status']  =  "400";
        $i = 1;
        if($data == 30){
            $result['message'] = " Geçersiz kullanıcı adı , şifre veya kullanıcınızın API erişim izninin olmadığını gösterir.
Ayrıca eğer API erişiminizde IP sınırlaması yaptıysanız ve sınırladığınız ip dışında gönderim sağlıyorsanız 30 hata kodunu alırsınız. API erişim izninizi veya IP sınırlamanızı , web arayüzümüzden; sağ üst köşede bulunan ayarlar> API işlemleri menüsunden kontrol edebilirsiniz.";
        }
        elseif ($data == 40){
            $result['message'] = " Gösterilecek mesajınızın olmadığını ifade eder. Api ile mesajlarınızı eğer startdate ve stopdate parametlerini kullanmıyorsanız sadece bir kere listeyebilirsiniz. Listelenen mesajlar diğer sorgulamalarınızda gelmez.";
        }
        elseif ($data == 50){
            $result['message'] = " Tarih formatı hatalıdır.";
        }
        elseif ($data == 60){
            $result['message'] = " Arama kiterlerindeki startdate ve stopdate zaman farkının 30 günden fazla olduğunu ifade eder.";
        }
        elseif ($data == 70){
            $result['message'] = " Hatalı sorgulama. Gönderdiğiniz parametrelerden birisi hatalı veya zorunlu alanlardan birinin eksik olduğunu ifade eder.";
        }
        else {
            $parts = explode('<br>', $data);

            $result['status']  =  "200";

            foreach ($parts as $part) {
                $messages = explode(' | ', $part);
                $result[$i]['phone'] = isset($messages[0]) ? $messages[0] : '';
                $result[$i]['message'] = isset($messages[1]) ? $messages[1] : '';
                $result[$i]['time'] = isset($messages[2]) ? $messages[2] : '';
                $i++;
            }
        }
        return ($result);
    }

    /*
     * Numarayı olası yabancı karakterlerden temizler.
     */
    public function getphoneClear($phone){
        $unwanted = array(' ', '+', '(', ')', '.', '-', '&amp;', 'nbsp;'  );
        $replace    = array('', '', '', '', '', '', '', '' );
        $result      = str_replace($unwanted, $replace, $phone);
        return $result;
    }

    /*
     * Müşterileri Netgsm rehberine belirtilen gruba aktarır.
     */
    public function setContact($datas, $groupName = 'Opencart')
    {
        if (count($datas)>500){
            $contacts = array_chunk($datas, 500);
            foreach ($contacts as $contact) {
                return $this->addContacts($contact, $groupName);
            }
        } else {
            return $this->addContacts($datas, $groupName);
        }
    }

    /*
     * Netgsm gruba ekleme xml dosyası oluşturur
     */
    public function addContacts($datas, $groupName = 'Opencart')
    {
        $body = '';
        foreach ($datas as $data) {
            $telephone = $this->getphoneClear($data['telephone']);
            $body .= '<tel>
                        <ad><![CDATA['.$data['firstname'].']]></ad>
                        <soyad><![CDATA['.$data['lastname'].']]></soyad>
                        <telefon><![CDATA['.$telephone.']]></telefon>
                    </tel>';
        }

        $xml = '<?xml version="1.0" encoding="iso-8859-9"?>
                <main>
                    <usercode>'.$this->usercode.'</usercode>
                    <pwd>'.$this->password.'</pwd>
                    <grup>'.$groupName.'</grup>
                   '.$body.'
                </main>';
        $response = $this->XMLPOST( 'http://api.netgsm.com.tr/contacts/group/add', $xml );
        return $response;
    }

    /*
     *  XML Kredi bilgisi
     */
    public function getCredit(){
        $requestUrl = 'https://api.netgsm.com.tr/balance/list/xml';
        $xml = "<?xml version='1.0'?><mainbody><header><company>Netgsm</company><usercode>".$this->usercode."</usercode><password>".$this->password."</password><stip>2</stip></header></mainbody>";
        $result = $this->XMLPOST($requestUrl, $xml);
        return $this->getCreditResult($result);
    }

    /*
     * Netsantral Reporları
     * Dakikada en fazla 2 kez sorgulanabilir
     */
    public function getVoipReport()
    {
        date_default_timezone_set('Europe/Istanbul');
        $startDate = date('dmYHi', time() - 60*60*24);
        $endDate = date('dmYHi', time());
        $PostAdress = 'https://api.netgsm.com.tr/netsantral/report/xml';
        $xml = "<?xml version='1.0'?>
            <mainbody>
                <header>
                    <company>Netgsm</company>
                    <usercode>".$this->usercode."</usercode>
                    <password>".$this->password."</password>
                    <startdate>".$startDate."</startdate>
                    <stopdate>".$endDate."</stopdate>
                    <version>3</version>
                </header>
            </mainbody>";
        $results = $this->XMLPOST($PostAdress,$xml);

        if ($results != '' && in_array(trim($results), [100,101])){
            $response = ['error'=>['code'=>trim($results), 'message'=>'Dakikada en fazla 2 kez sorgulanabilir.']];
            return json_encode($response,256);
        }
        if ($results != '' && in_array(trim($results), [40])){
            $response = ['error'=>['code'=>trim($results), 'message'=>'Listelenecek kayıt yok.']];
            return json_encode($response,256);
        }
        if ($results != '' && in_array(trim($results), [30])){
            $response = ['error'=>['code'=>trim($results), 'message'=>'Geçersiz kullanıcı adı, şifre veya kullanıcınızın API erişim izniniz yok.']];
            return json_encode($response,256);
        }

        if ($results != '' && in_array(trim($results), [50])){
            $response = ['error'=>['code'=>trim($results), 'message'=>'Tarih formatının hatalı.']];
            return json_encode($response,256);
        }

        if ($results != '' && in_array(trim($results), [60])){
            $response = ['error'=>['code'=>trim($results), 'message'=>'Zaman farkının 7 günden fazla']];
            return json_encode($response,256);
        }

        if ($results != '' && in_array(trim($results), [70])){
            $response = ['error'=>['code'=>trim($results), 'message'=>'Hatalı sorgulama.']];
            return json_encode($response,256);
        }

        if ($results != '' && in_array(trim($results), [80])){
            $response = ['error'=>['code'=>trim($results), 'message'=>'Netsantral hizmeti kullanılmıyor.']];
            return json_encode($response,256);
        }

        $results = explode('<br/>', $results);

        $response = [];
        foreach ($results as $result) {
            $result = trim($result);
            $cdr = explode('|', $result);
            $temp = [];
            if(isset($cdr[0]) && $cdr[0] != '') {
                $temp['call_id'] = $cdr[0];
                $temp['date'] = $cdr[1];
                $temp['dial_number'] = $cdr[2];
                $temp['caller_number'] = $cdr[3];
                $temp['time'] = $cdr[4];
                $temp['direction'] = $cdr[5];
                //$temp['recording'] = $cdr[6];
                array_push($response, $temp);
            }
        }
        $json['success'] = ['message'=>'Son 24 saatin kayıtları listeleniyor.'];
        $json['data'] = $response;

        return json_encode($json,256);
    }

    /*
     * Santral Raporları (Sabit Telefon)
     * Dakikada en fazla 2 kez sorgulanabilir
     */
    public function getPhoneReport()
    {
        $PostAdress = 'https://api.netgsm.com.tr/voice/report/xml';
        $xml = "<?xml version='1.0'?>
            <mainbody>
                <header>
                    <company>Netgsm</company>
                    <usercode>".$this->usercode."</usercode>
                    <password>".$this->password."</password>
                    <date></date>
                    <direction>4</direction>
                </header>
            </mainbody>";
        $results = $this->XMLPOST($PostAdress,$xml);

        if ($results != '' && in_array(trim($results), [100,101])){
            $response = ['error'=>['code'=>trim($results), 'message'=>'Dakikada en fazla 2 kez sorgulanabilir.']];
            return json_encode($response,256);
        }
        if ($results != '' && in_array(trim($results), [40])){
            $response = ['error'=>['code'=>trim($results), 'message'=>'Listelenecek kayıt yok.']];
            return json_encode($response,256);
        }
        if ($results != '' && in_array(trim($results), [30])){
            $response = ['error'=>['code'=>trim($results), 'message'=>'Geçersiz kullanıcı adı, şifre veya kullanıcınızın API erişim izniniz yok.']];
            return json_encode($response,256);
        }

        if ($results != '' && in_array(trim($results), [50])){
            $response = ['error'=>['code'=>trim($results), 'message'=>'Tarih formatının hatalı.']];
            return json_encode($response,256);
        }

        if ($results != '' && in_array(trim($results), [70])){
            $response = ['error'=>['code'=>trim($results), 'message'=>'Hatalı sorgulama.']];
            return json_encode($response,256);
        }

        $results = explode('<br/>', $results);
        $response = [];
        foreach ($results as $result) {
            $result = trim($result);
            $cdr = explode(' | ', $result);
            $temp = [];
            if(isset($cdr[0]) && $cdr[0] != '') {
                $temp['caller_number'] = $cdr[0];
                $temp['date'] = $cdr[1];
                $temp['time'] = $cdr[2];
                $temp['direction'] = $cdr[3];
                array_push($response, $temp);
            }
        }
        $json['success'] = ['message'=>'Bugünün kayıtları listeleniyor.'];
        $json['data'] = $response;

        return json_encode($json,256);
    }

    /*
     * XML POST işlerini yürütür
     */
    private function XMLPOST($requestUrl, $xmlData)
    {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL,$requestUrl);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST,false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER,0);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, Array("Content-Type: text/xml"));
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $xmlData);
        $result = curl_exec($ch);
        return $result;
    }

    /*
     *  Başlıkları parçalar
     */
    private function getHeaderResult($result){
        if($result == 30){
            return 'Geçersiz kullanıcı adı , şifre veya kullanıcınızın API erişim izninin olmadığını gösterir.
Ayrıca eğer API erişiminizde IP sınırlaması yaptıysanız ve sınırladığınız ip dışında gönderim sağlıyorsanız 30 hata kodunu alırsınız. API erişim izninizi veya IP sınırlamanızı , web arayüzümüzden; sağ üst köşede bulunan ayarlar> API işlemleri menüsunden kontrol edebilirsiniz.';
        }
        $response = explode('<br>', $result);
        return $response;
    }

    /*
     * Kredi sonucunu yorumlar
     */
    private function getCreditResult($result){
        $array = explode(' ',$result);
        $error_code = $array[0];
        if($error_code==30){
            $response = '30Geçersiz kullanıcı adı , şifre veya kullanıcınızın API erişim izninin olmadığını gösterir.
Ayrıca eğer API erişiminizde IP sınırlaması yaptıysanız ve sınırladığınız ip dışında gönderim sağlıyorsanız 30 hata kodunu alırsınız. API erişim izninizi veya IP sınırlamanızı , web arayüzümüzden; sağ üst köşede bulunan ayarlar> API işlemleri menüsunden kontrol edebilirsiniz.';
        }elseif($error_code==40){
            $response = '40Arama kriterlerinize göre listelenecek kayıt olmadığını ifade eder.';
        }elseif($error_code==70){
            $response = '70Hatalı sorgulama. Gönderdiğiniz parametrelerden birisi hatalı veya zorunlu alanlardan birinin eksik olduğunu ifade eder.';
        }else{
            $response = '99'.$array[1];
        }

        return $response;
    }

    /*
     * Paketler
     */
    public function getAsset(){
        $requestUrl = 'https://api.netgsm.com.tr/balance/list/xml';
        $xml = "<?xml version='1.0'?><mainbody><header><company>Netgsm</company><usercode>".$this->usercode."</usercode><password>".$this->password."</password><stip>1</stip></header></mainbody>";
        $result = $this->XMLPOST($requestUrl, $xml);
        if($result==30){
            return '-';
        }
        return $result;
    }

    /*
     * Netgsm rehberine kişi ekler.
     */
    public function addContact($first_name, $last_name, $phone, $groupName= 'Müşteriler')
    {
        $requestUrl = 'http://api.netgsm.com.tr/contacts/group/add';
        $xml = '<?xml version="1.0" encoding="iso-8859-9"?>
        <main>
            <usercode>'.$this->usercode.'</usercode>
            <pwd>'.$this->password.'</pwd>
            <grup>'.$groupName.'</grup>
            <tel>
                <ad><![CDATA['.$first_name.']]></ad>
                <soyad><![CDATA['.$last_name.']]></soyad>
                <telefon><![CDATA['.$this->getphoneClear($phone).']]></telefon>
            </tel>
        </main>';
        $response = $this->XMLPOST( $requestUrl, $xml );
        return $response;
    }


}