<?php
class ControllerCheckoutSuccess extends Controller {
	public function index() {
		$this->load->language('checkout/success');

		if (isset($this->session->data['order_id'])) {
			$this->cart->clear();


            $this->load->model('setting/setting');
            $netgsm_ayarlari = $this->model_setting_setting->getSetting('netgsm');

            $this->load->model('account/order');
                $urunler = $this->model_account_order->getOrderProducts($this->session->data['order_id']);
                $urun_adlari     = "";
                $urun_kodlari    = "";
                $urun_adetleri = "";
                foreach ($urunler as $key => $value) {
                    if ($key==0){ $ayrac = ''; }else{ $ayrac = ','; }
                    $urun_adlari     .= $ayrac.$value['name'];
                    $urun_kodlari    .= $ayrac.$value['model'];
                    $urun_adetleri .= $ayrac.$value['quantity'];
                }

            if($netgsm_ayarlari['netgsm_status']==1 and isset($netgsm_ayarlari['netgsm_neworder_to_admin_control']) and $netgsm_ayarlari['netgsm_neworder_to_admin_control']==1 and $netgsm_ayarlari['netgsm_neworder_to_admin_text']!=''){
                $mesaj = str_replace(array('[siparis_no]','[urun_adlari]','[urun_kodlari]','[urun_adetleri]'),array($this->session->data['order_id'],$urun_adlari,$urun_kodlari,$urun_adetleri),$netgsm_ayarlari['netgsm_neworder_to_admin_text']);
                $netgsmsms = new Netgsmsms($netgsm_ayarlari['netgsm_user'],$netgsm_ayarlari['netgsm_pass'],$netgsm_ayarlari['netgsm_input_smstitle'],$netgsm_ayarlari['netgsm_turkishChar']);
                $smsgonder = $netgsmsms->sendSMS($netgsm_ayarlari['netgsm_neworder_to_admin_no'],$mesaj);
            }

            if($netgsm_ayarlari['netgsm_status']==1 and isset($netgsm_ayarlari['netgsm_neworder_to_customer_control']) and $netgsm_ayarlari['netgsm_neworder_to_customer_control']==1 and $netgsm_ayarlari['netgsm_neworder_to_customer_text']!=''){
                $this->load->model('account/customer');
                    if ($this->customer->isLogged())  {
                        $customer_info = $this->model_account_customer->getCustomer($this->session->data['customer_id']);
                        $telefon = $customer_info['telephone'];
                    } else {
                        $telefon = $this->session->data['guest']['telephone'];
                    }
                    $mesaj = str_replace(array('[siparis_no]','[urun_adlari]','[urun_kodlari]','[urun_adetleri]'),array($this->session->data['order_id'],$urun_adlari,$urun_kodlari,$urun_adetleri),$netgsm_ayarlari['netgsm_neworder_to_customer_text']);
                $netgsmsms = new Netgsmsms($netgsm_ayarlari['netgsm_user'],$netgsm_ayarlari['netgsm_pass'],$netgsm_ayarlari['netgsm_input_smstitle'],$netgsm_ayarlari['netgsm_turkishChar']);
                $smsgonder = $netgsmsms->sendSMS($telefon,$mesaj);
            }
                        

			unset($this->session->data['shipping_method']);
			unset($this->session->data['shipping_methods']);
			unset($this->session->data['payment_method']);
			unset($this->session->data['payment_methods']);
			unset($this->session->data['guest']);
			unset($this->session->data['comment']);
			unset($this->session->data['order_id']);
			unset($this->session->data['coupon']);
			unset($this->session->data['reward']);
			unset($this->session->data['voucher']);
			unset($this->session->data['vouchers']);
			unset($this->session->data['totals']);
		}

		$this->document->setTitle($this->language->get('heading_title'));

		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/home')
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_basket'),
			'href' => $this->url->link('checkout/cart')
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_checkout'),
			'href' => $this->url->link('checkout/checkout', '', true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_success'),
			'href' => $this->url->link('checkout/success')
		);

		if ($this->customer->isLogged()) {
			$data['text_message'] = sprintf($this->language->get('text_customer'), $this->url->link('account/account', '', true), $this->url->link('account/order', '', true), $this->url->link('account/download', '', true), $this->url->link('information/contact'));
		} else {
			$data['text_message'] = sprintf($this->language->get('text_guest'), $this->url->link('information/contact'));
		}

		$data['continue'] = $this->url->link('common/home');

		$data['column_left'] = $this->load->controller('common/column_left');
		$data['column_right'] = $this->load->controller('common/column_right');
		$data['content_top'] = $this->load->controller('common/content_top');
		$data['content_bottom'] = $this->load->controller('common/content_bottom');
		$data['footer'] = $this->load->controller('common/footer');
		$data['header'] = $this->load->controller('common/header');

		$this->response->setOutput($this->load->view('common/success', $data));
	}
}