<?php
// Text
$_['text_success']     = 'Başarılı!Ödül Puanınız başarıyla uygulandı!';

// Error
$_['error_permission']   = 'Dikkat: API erişme yetkiniz ok!';
$_['error_reward']     = 'Uyarı: kullanmak için ödül puanı miktarını giriniz!';
$_['error_points']     = 'Dikkat   %s kadar Ödül puanınız yok!';
$_['error_maximum']    = 'Uyarı: uygulanabilir puan maksimum tutarınız %s!';