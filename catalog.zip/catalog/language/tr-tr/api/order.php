<?php
// Türkçe ye Çeviri : www.tr-opencart.com osdem66
// Text
$_['text_success']           = 'Siaprişiniz başarıyla siparişlerde düzenlendi';

// Error
$_['error_permission']       = 'Dikkat: API erişme yetkiniz ok';
$_['error_customer']         = 'Müşteri bilgilerini düzenlemek gerekiyor!';
$_['error_payment_address']  = 'Ödeme adresi gereklidir!';
$_['error_payment_method']   = 'Ödeme yöntemi gerekli!';
$_['error_no_payment']       = 'Uyarı: Hiçbir ödeme metodu kullanılabilir Değil!';
$_['error_shipping_address'] = 'Kargo adresi gereklidir!';
$_['error_shipping_method']  = 'Kargo yöntemi gerekli!';
$_['error_no_shipping']      = 'Uyarı: Hiçbir kargo metodu kullanılabilir Değil!';
$_['error_stock']            = '*** ile işaretli ürünler istenilen miktarda veya stokta mevcut değil!';
$_['error_minimum']          = '%s ürünü için minimum sipariş miktarı %s!';
$_['error_not_found']        = 'Uyarı: Sipariş bulunamadı!';