<?php
// Text
$_['text_success']       = 'Müşteriler Başarıyla düzenlendi';

// Error
$_['error_permission']   = 'Dikkat: API erişme yetkiniz ok!';
$_['error_firstname']    = 'İsminiz 1 ile 32 Karekter arasında olmalıdır!';
$_['error_lastname']     = 'Soaydınız 1 ile 32 karekter arasında olmalıdır!';
$_['error_email']        = 'Geçerli bir e-posta adresi giriniz!';
$_['error_telephone']    = 'Telefon numaranız 3 ile 32 karketer arasında olmalıdır!';
$_['error_custom_field'] = '%s Alanı gereklidir!';