<?php
// Text
$_['text_success']     = 'Başarılı!Kupon kodunuz başarıyla uygulandı!';

// Error
$_['error_permission'] = 'Dikkat: API erişme yetkiniz ok!';
$_['error_coupon']     = 'Uyarı: Kupon ya geçersiz, Süresi doldu yada Kullanım limiti doldu!';