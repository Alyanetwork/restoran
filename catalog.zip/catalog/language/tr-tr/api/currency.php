<?php
// Text
$_['text_success']     = 'Başarılı: Parabiriniz degiştirildi!';

// Error
$_['error_permission'] = 'Dikkat:  API! Düzenlemeye yetkinizyok';
$_['error_currency']   = 'Dikkat: Parabirimi Kodu Yanlış!';