<?php
// Text
$_['text_success'] = 'Başarılı: API oturumu başarıyla Açıldı!';

// Error
$_['error_key']    = 'Uyarı: API anahtarı yanlış!';
$_['error_ip']     = 'Uyarı: IP %s adresinizden API erişimine izin verilmiyor!';