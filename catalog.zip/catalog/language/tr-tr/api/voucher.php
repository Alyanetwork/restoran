<?php
// Türkçe ye Çeviri osdem66: www.tr-opencart.com
// Text
$_['text_success']     = 'Başarılı!Hediye çekiniz başarıyla uygulandı!';
$_['text_cart']        = 'Başarılı: Alışveriş sepetiniz başarıyla düzenlendi!';

$_['text_for']         = '%s Için Hediye Çeki %s';

// Error
$_['error_permission']   = 'Dikkat: API erişme yetkiniz ok!';
$_['error_voucher']    = 'Uyarı: Hediye Çeki geçersiz veya tutarı kadar kullanılmıştır!';
$_['error_to_name']    = 'Alıcı \ Adı 1 ile 64 karakter arasında olmalıdır!';
$_['error_from_name']  = 'Adınız 1 ile 64 karakter arasında olmalıdır!';
$_['error_email']      = 'E-Posta Adresiniz geçerli görünmüyor!';
$_['error_theme']      = 'Bir hedie çeki tema seçmeniz gerekir!';
$_['error_amount']     = 'Tutar %s ile %s arasında olmalıdır!';