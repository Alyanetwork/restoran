<?php
// Text
$_['text_success']     = 'Başarılı: Alışveriş sepetiniz başarıyla düzenlendi!';

// Error
$_['error_permission'] = 'Dikkat: API erişme yetkiniz ok!';
$_['error_stock']      = '*** ile işaretli ürünler istenilen miktarda veya stokta mevcut değildir!';
$_['error_minimum']    = 'Minumum sipariş miktarı %s ile %s arasında olmalıdır!';
$_['error_store']      = 'Ürün seçtiğiniz mağazadan satınalınamaz!';
$_['error_required']   = '%s Alanı gereklidir!';