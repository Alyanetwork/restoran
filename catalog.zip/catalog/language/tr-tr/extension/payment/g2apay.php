<?php
// Text
$_['text_title'] = 'Kredi Kartı / Debit Kart / Paypal / Wallet (G2APay)';