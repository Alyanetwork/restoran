<?php
// Türkçe ye Çeviri OSDEM66 : www.tr-opencart.com




// Text
$_['text_title'] = 'Ücretsiz Ödeme';
