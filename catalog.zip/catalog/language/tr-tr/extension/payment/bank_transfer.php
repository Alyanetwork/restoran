<?php
// Türkçe ye Çeviri : www.tr-opencart.com



// Text
$_['text_title']       = 'Banka Havalesi/EFT';
$_['text_instruction'] = 'Banka Havalesi/EFT Talimatları';
$_['text_description'] = 'Lütfen aşağıdaki banka hesaplarına Sipariş Tuttırını yatırınız.';
$_['text_payment']     = 'Siparişinizi verdikten sonraki 5 iş günü içinde belirtilen hesap numaralarına havale yapmadınız taktirde siparişiniz iptal olur.';
