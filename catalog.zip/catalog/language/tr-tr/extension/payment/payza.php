<?php
// Türkçe ye Çeviri : www.tr-opencart.com

// Text
$_['text_title'] = 'Kredi Kart / Bank Kart (Payza)';
?>