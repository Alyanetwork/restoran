<?php
// Türkçe ye Çeviri : www.tr-opencart.com



// Text
$_['text_title'] = 'Kredi Kartı / Bankamatik Kartı (Authorize.Net)';
