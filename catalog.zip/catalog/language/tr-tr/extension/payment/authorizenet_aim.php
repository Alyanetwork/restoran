<?php
// Türkçe ye Çeviri : www.tr-opencart.com



// Text
$_['text_title']           = 'Kerdi / Debit kart (Authorize.Net)';
$_['text_credit_card']     = 'Kart Bilgileri';

// Entry
$_['entry_cc_owner']       = 'Kart Sahibi:';
$_['entry_cc_number']      = 'Kart Numarası:';
$_['entry_cc_expire_date'] = 'Kart Geçerlilik Tarihi:';
$_['entry_cc_cvv2']        = 'Güvenlik Kodu (CVV2):';
