<?php
// Türkçe ye Çeviri Osdem66: www.tr-opencart.com



// Text
$_['text_title']	= 'PayPal';
$_['text_testmode']	= 'DİKKAT!!! Ödeme metodu \'Test Modundadır\'. Hesabınıza tahsilat yapılmayacaktır.';
$_['text_total']	= 'Ambalajlama, Kargolama, İndirimler & Vergiler';
