<?php
// T�rk�e ye �eviri : www.tr-opencart.com

$_['express_text_title']		= 'Sipari� Onayla';

// Text
$_['text_title'] = 'PayPal Ekspress';
$_['button_continue']			= 'devam';
$_['text_cart']					= 'Al��veri� Sepeti';
$_['text_shipping_updated']		= 'Nakliye hizmeti g�ncellendi';
$_['text_trial']				= '%s her %s %s i�in %s �demeden sonra ';
$_['text_recurring']			= '%s her %s %s';
$_['text_recurring_item']		= 'yinelenen ��e';
$_['text_length']				= ' �deme %s ��in';

// Entry
$_['express_entry_coupon']		= 'Kuponunuzu giriniz:';

// Button
$_['express_button_coupon']		= 'ekle;
$_['express_button_confirm']	= 'Onayla';
$_['express_button_login']		= 'PayPalva git';
$_['express_button_shipping']	= 'Kargoyu g�ncelle';
$_['button_cancel_recurring']	= '�demeleri �ptal et';

// Error
$_['error_heading_title']		= 'Herhangi bir hata yok';
$_['error_too_many_failures']	= '�demeniz �ok kez ba�ar�s�z oldu';