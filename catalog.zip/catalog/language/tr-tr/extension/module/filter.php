<?php
// T�rk�e ye �eviri :osdem66 www.tr-opencart.com
// Heading
$_['heading_title'] = 'Filtreleme';
