<?php
// T�rk�e ye �eviri : www.tr-opencart.com



// Heading
$_['heading_title'] = 'Kategoriler';
?>