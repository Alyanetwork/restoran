<?php
// Türkçe ye Çeviri : www.tr-opencart.com



// Heading 
$_['heading_title']  = 'En Çok Satanlar';

// Text
$_['text_tax']      = 'Kdv Hariç:';