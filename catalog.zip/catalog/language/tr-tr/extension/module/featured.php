<?php
// Türkçe ye Çeviri :osdem66  www.tr-opencart.com



// Heading 
$_['heading_title']  = 'Özel Ürünler';

// Text
$_['text_tax']      = 'Kdv Hariç:';