<?php
// Türkçe ye Çeviri : www.tr-opencart.com



// Heading 
$_['heading_title'] = 'Mağaza Degiştir';

// Text
$_['text_default']  = 'Varsayılan';
$_['text_store']    = 'Gitmek istediğiniz mağazayı seçiniz.';
?>