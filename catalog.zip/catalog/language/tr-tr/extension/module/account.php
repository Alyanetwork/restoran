<?php
// Türkçe ye Çeviri : www.tr-opencart.com



// Heading 
$_['heading_title']    = 'Profilim';

// Text
$_['text_register']    = 'Üye Ol';
$_['text_login']       = 'Giriş Yap';
$_['text_logout']      = 'Çıkış Yap';
$_['text_forgotten']   = 'Şifremi Unuttum';
$_['text_account']     = 'Profilim';
$_['text_edit']        = 'Profili Düzenle';
$_['text_password']    = 'Şifre Değiştir';
$_['text_address']     = 'Adres Defteri';
$_['text_wishlist']    = 'Alışveriş Listem';
$_['text_order']       = 'Sipariş Geçmişim';
$_['text_download']    = 'İndirilebilir Ürünlerim';
$_['text_reward']      = 'Ödül Puan';
$_['text_return']      = 'Ürün İade Taleplerim';
$_['text_transaction'] = 'Alım Satım İşlemleri';
$_['text_newsletter']  = 'Mail Aboneliği';
$_['text_recurring']   = 'Otomatik Ödeme';