<?php
// Türkçe ye Çeviri : www.tr-opencart.com



// Heading 
$_['heading_title'] = 'Bilgiler';

// Text
$_['text_contact']  = 'İletişim';
$_['text_sitemap']  = 'Site Haritası';
