<?php
// Türkçe ye Çeviri : www.tr-opencart.com osdem66

// Text
$_['text_captcha']  = 'Doğrulama Kodu';

// Entry
$_['entry_captcha'] = 'Lütfen captcha doğrulamasını tamamlayın.';

// Error
$_['error_captcha'] = 'Doğrulama doğru değil!';