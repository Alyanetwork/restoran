<?php
// Türkçe ye Çeviri : www.tr-opencart.com



// Heading
$_['heading_title'] = 'Ortaklık Programına Kayıt Oldunuz!';

// Text 
$_['text_approval'] = '<p>%s Ortaklı programına kayıt olduğunuz için teşekkür ederiz!</p><p>Üyeliğiniz mağaza sahibi tarafından onaylandıktan sonra e-posta ile bilgilendirileceksiniz</p><p>Ortaklık programı ile ilgili herhangi bir sorunuz varsa mağaza sahibi ile <a href="%s">iletişime</a> geçebilirsiniz.</p>';
$_['text_account']  = 'Ortaklık Profilim';
$_['text_success']  = 'Başarılı';
