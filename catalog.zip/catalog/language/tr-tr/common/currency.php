<?php
// T�rk�e ye �eviri : www.tr-opencart.com osdem66
// Text
$_['text_currency'] = 'Para Birimi';