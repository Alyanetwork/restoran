<?php
// Türkçe ye Çeviri : www.tr-opencart.com osdem66
// Text
$_['text_search'] = 'Arama Yapınız...!';