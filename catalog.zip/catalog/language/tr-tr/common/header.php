<?php
// Türkçe ye Çeviri : www.tr-opencart.com



// Text
$_['text_home']		= 'Anasayfa';
$_['text_wishlist'] = 'Alışveriş Listem (%s)';
$_['text_shopping_cart'] = 'Sepetim';
$_['text_category']      = 'Kategoriler';
$_['text_account']       = 'Hesabım';
$_['text_register']      = 'Üye Ol';
$_['text_login']         = 'Giriş';
$_['text_order']         = 'Sipariş Geçmişi';
$_['text_transaction']   = 'İşlemler';
$_['text_download']      = 'İndirme';
$_['text_logout']        = 'Çıkış';
$_['text_checkout'] = 'Kasaya Git';
$_['text_search']	= 'Arama Yapınız';
$_['text_all']           = 'Tamamını Gör';