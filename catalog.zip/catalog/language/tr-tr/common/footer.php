<?php

// Text
$_['text_information']  = 'Bilgiler';
$_['text_service']      = 'Müşteri Servisi';
$_['text_extra']        = 'Ekstralar';
$_['text_contact']      = 'İletişim';
$_['text_return']       = 'Ürün İadesi';
$_['text_sitemap']      = 'Site Haritası';
$_['text_manufacturer'] = 'Markalar';
$_['text_voucher']      = 'Hediye Çeki';
$_['text_affiliate']    = 'Ortaklık Programı';
$_['text_special']      = 'Kampanyalar';
$_['text_account']      = 'Profilim';
$_['text_order']        = 'Sipariş Geçmişim';
$_['text_wishlist']     = 'Alışveriş Listem';
$_['text_newsletter']   = 'Mail Aboneliği';
$_['text_powered']      = 'E-ticaret <a href="https://www.opencartuzman.com">OpencartUzman</a><br />';