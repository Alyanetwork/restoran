<?php
// Türkçe ye Çeviri : www.tr-opencart.com osdem66
// Text
$_['text_items']    = '%s ürün - %s';
$_['text_empty']    = 'Sepete Henüz Ürün eklemediniz!';
$_['text_cart']     = 'Sepeti Göster';
$_['text_checkout'] = 'Ödeme Yap';
$_['text_recurring']  = 'Ödeme Profili';