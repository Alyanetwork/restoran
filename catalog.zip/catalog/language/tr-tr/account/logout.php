<?php
// Türkçe ye Çeviri : www.tr-opencart.com



// Heading 
$_['heading_title'] = 'Çıkış Yap';

// Text
$_['text_message']  = '<p>Güvenli bir şekilde Çıkış Yaptınız. Güvenli bir şekilde bilgisayarı terk edebilirsiniz.</p><p>Alışveriş sepetiniz kaydedildi, bir dahaki oturumunuz da kaldığınız yerden devam edebilirsiniz.</p>';
$_['text_account']  = 'Profilim';
$_['text_logout']   = 'Çıkış Yap';
