<?php
// T�rk�e ye �eviri : www.tr-opencart.com osdem66
$_['heading_title'] = 'Oto Payments';

// Text
$_['text_account']                         = 'Hesab�m';
$_['text_recurring']                       = 'Otomatik �deme';
$_['text_recurring_detail']                = 'Otomatik �deme Detaylar�';
$_['text_order_recurring_id']              = 'Abonelik No:';
$_['text_date_added']                      = 'Ekleme Tarihi:';
$_['text_status']                          = 'Durum:';
$_['text_payment_method']                  = '�deme Metodu:';
$_['text_order_id']                        = 'Sipari� No:';
$_['text_product']                         = '�r�n:';
$_['text_quantity']                        = 'Adet:';
$_['text_description']                     = 'A��klama';
$_['text_reference']                       = 'Referans';
$_['text_transaction']                     = '��lemler';


$_['text_status_1']                        = 'Aktif';
$_['text_status_2']                        = 'Pasif';
$_['text_status_3']                        = '�ptal Edildi';
$_['text_status_4']                        = 'Ask�ya Al�nm��';
$_['text_status_5']                        = 'S�resi Bitmi�';
$_['text_status_6']                        = 'Onay Bekliyor';

$_['text_transaction_date_added']          = 'Olu�turuldu';
$_['text_transaction_payment']             = '�deme';
$_['text_transaction_outstanding_payment'] = 'Ola�an�st� �deme';
$_['text_transaction_skipped']             = '�deme Atland�';
$_['text_transaction_failed']              = '�deme Ba�ar�s�z';
$_['text_transaction_cancelled']           = '�ptal Edildi';
$_['text_transaction_suspended']           = 'Ask�ya Al�nd�';
$_['text_transaction_suspended_failed']    = 'Ba�ar�s�z �demeden Ask�ya Al�nd�';
$_['text_transaction_outstanding_failed']  = 'Ola�an�st� �deme Ba�ar�s�z';
$_['text_transaction_expired']             = 'S�resi Ge�di';

$_['text_empty']                           = 'Otomatik �deme yok.';
$_['text_error']                           = '�stedi�iniz otomatik �deme sipari�i bulunamad�!';

$_['text_cancelled']                       = 'Otomatik �deme �u an iptal edildi';

// Column
$_['column_date_added']                    = 'Olu�turuldu';
$_['column_type']                          = 'T�r�';
$_['column_amount']                        = 'Adet';
$_['column_status']                        = 'Durum';
$_['column_product']                       = '�r�n';
$_['column_order_recurring_id']            = 'Abonelik No';

// Error
$_['error_not_cancelled']                  = 'Hata: %s';
$_['error_not_found']                      = 'Otomatik �deme iptal edilemedi';

// Button
$_['button_return']                        = '�ade';