<?php
// Türkçe ye Çeviri : www.tr-opencart.com



// Heading 
$_['heading_title']   = 'İndirebilir Ürünler';

// Text
$_['text_account']    = 'Profilim';
$_['text_downloads']  = 'İndirebilir Ürünler';
$_['text_empty']      = 'Daha önce indirilebilir ürünü Satın Almadınız !';
$_['column_order_id']      = 'Sipariş ID:';
$_['column_date_added'] = 'Ekleme Tarihi:';
$_['column_name']       = 'Adı:';
$_['column_size']       = 'Boyutu:';

