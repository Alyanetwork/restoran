<?php
// Türkçe ye Çeviri : www.tr-opencart.com



// Heading
$_['heading_title'] = 'Kayıt Oldunuz!';

// Text
$_['text_message']  = '<p>Tebrikler! Başarılı bir şekilde Kayıt oldunuz! Artık beğendiniz ürünlerimizi sipariş verebilirsiniz.</p><p>Üyeliğiniz hakkında e-posta adresinize bir mesaj gönderildi. Eğer 1 saat içinde gönderilmezse, lütfen <a href="%s">bizimle iletişime</a> geçin.</p>';
$_['text_approval'] = '<p>Üye olduğunuz için teşekkür ederiz %s! Hesabınızın mağaza sahibi tarafından etkinleştirildiğinde e-posta ile bildirilecektir.</p><p>Herhangi bir sorunuz varsa, lütfen mağaza sahibi ile <a href="%s">iletişime</a> geçin.</p>';
$_['text_account']  = 'Profilim';
$_['text_success']  = 'Başarılı';
