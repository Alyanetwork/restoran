<?php
// Türkçe ye Çeviri : www.tr-opencart.com



// Heading 
$_['heading_title']   = 'Parolamı Unutum?';

// Text
$_['text_account']    = 'Profilim';
$_['text_forgotten']  = 'Parolamı Unuttum';
$_['text_your_email'] = 'E-Posta Adresiniz';
$_['text_email']      = 'Kayıt olurken verdiğiniz e-posta adresinizi yazınız. Şifreniz e-posta adresinize gönderilecektir.';
$_['text_success']    = ': Yeni parolanız Başarılı bir şekilde e-posta adresinize gönderildi.';

// Entry
$_['entry_email']     = 'E-Posta Adresiniz:';
$_['entry_password']  = 'Yeni Parolanız';
$_['entry_confirm']   = 'Yeni Parola(tekrar)';

// Error
$_['error_email']     = 'Dikkat: E-Posta adresi bulunamadı. Lütfen tekrar deneyiniz!';
$_['error_approved']  = 'Uyarı: Giriş yapmadan önce hesabınızın onaylanması gereklidir!';
$_['error_password']  = 'Parolanız 4 ile 20 karakter arasında olmalıdır!';
$_['error_confirm']   = 'Yazdığınız parolar birbiri ile uyuşmuyor!';