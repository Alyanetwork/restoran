<?php
// Türkçe ye Çeviri : www.tr-opencart.com



// Heading 
$_['heading_title']      = 'Profilim';

// Text
$_['text_account']       = 'Profilim';
$_['text_my_account']    = 'Profilim';
$_['text_my_orders']     = 'Siparişlerim';
$_['text_my_newsletter'] = 'Mail Aboneliği';
$_['text_edit']          = 'Profil bilgilerimi düzenle';
$_['text_password']      = 'Parola değiştir';
$_['text_address']       = 'Adres defterlerini değiştirin';
$_['text_wishlist']      = 'Alışveriş Listemi Düzenle';
$_['text_order']         = 'Sipariş geçmişimi İncele';
$_['text_download']      = 'İndirebilir Ürünler';
$_['text_reward']        = 'Ödül Puanlarım'; 
$_['text_return']        = 'Ürün iade Taleplerimi İncele'; 
$_['text_transaction']   = 'Alım - Satım İşlemleriniz';
$_['text_newsletter']    = 'Bültene Abone ol / Aboneliği kaldır.';
$_['text_recurring']     = 'Recurring payments';
$_['text_transactions']  = 'Transactions';
$_['text_affiliate_add']  = 'Ortaklık hesabı için Üye ol';
$_['text_affiliate_edit'] = 'Ortaklık bilgilerini düzenle';
$_['text_tracking']       = 'Özel Ortaklık Takip Kodu';