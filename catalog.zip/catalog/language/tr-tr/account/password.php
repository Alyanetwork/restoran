<?php
// Türkçe ye Çeviri : www.tr-opencart.com



// Heading 
$_['heading_title']  = 'Şifre Değiştir';

// Text
$_['text_account']   = 'Hesabım';
$_['text_password']  = 'Şifrenız';
$_['text_success']   = 'Başarılı: Şifrenız başarılı bir şekilde güncellendi.';

// Entry
$_['entry_password'] = 'Şifre:';
$_['entry_confirm']  = 'Şifre (Tekrar):';

// Error
$_['error_password'] = 'Şifrenız 4 ile 20 karakter arasında olmalı!';
$_['error_confirm']  = 'Şifrenız birbiriyle uyuşmuyor!';
