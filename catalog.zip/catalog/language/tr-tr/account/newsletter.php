<?php
// Türkçe ye Çeviri : www.tr-opencart.com



// Heading 
$_['heading_title']    = 'Mail Aboneliği';

// Text
$_['text_account']     = 'Profilim';
$_['text_newsletter']  = 'Mail Aboneliği';
$_['text_success']     = 'Başarılı: Mail aboneliğiniz başarılı bir şekilde güncellendi!';

// Entry
$_['entry_newsletter'] = 'Abonelik:';
