<?php
// Türkçe ye Çeviri : www.tr-opencart.com



// Heading 
$_['heading_title']      = 'Ödül Puanlarım';

// Column
$_['column_date_added']  = 'Ekleme Tarihi';
$_['column_description'] = 'Açıklama';
$_['column_points']      = 'Puan';

// Text
$_['text_account']       = 'Profilim';
$_['text_reward']        = 'Ödül Paunlarım';
$_['text_total']         = 'Toplam ödül puanınız:';
$_['text_empty']         = 'Hiç ödül puanınız yok!';
