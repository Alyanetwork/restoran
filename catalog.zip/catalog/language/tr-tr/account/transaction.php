<?php
// Türkçe ye Çeviri : www.tr-opencart.com



// Heading 
$_['heading_title']      = 'Alım/Satım İşlemlerim';

// Column
$_['column_date_added']  = 'Ekleme Tarihi';
$_['column_description'] = 'Açıklama';
$_['column_amount']      = 'Miktar (%s)';

// Text
$_['text_account']       = 'Profilim';
$_['text_transaction']   = 'Alım/Satım İşlemlerim';
$_['text_total']         = 'Geçerli bakiyeniz:';
$_['text_empty']         = 'Alım/satım işleminiz bulunmuyor!';
