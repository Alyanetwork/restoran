<?php
// Türkçe ye Çeviri : www.tr-opencart.com



// Heading
$_['heading_title'] = 'Siparişiniz Başarılışekilde Tamamlandı!';

// Text
$_['text_basket']	= 'Sepetim';
$_['text_checkout']	= 'Kasaya Git';
$_['text_success']	= 'Başarılı';
$_['text_customer']        = '<p>Siparişiniz başarıyla tarafımıza ulaşmıştır!</p><p>Sipariş geçmişinizi incelemek için <a href="%s">Hesabım</a> Sayfasına giderek <a href="%s">Sipariş geçmişini</a>inceleyebilirsiniz.</p><p>Eğer indirilebilir ürün siparişi verdiyseniz  <a href="%s">İndirilebilir Ürünler</a> Sayfasını ziyaret edebilirsiniz.</p><p>Herhangi bir sorununuz var ise  <a href="%s">Mağaza Müşteri İlişikleri</a> bölümüne bildirebilirsiniz..</p><p>Mağazamızdan alışveriş yaptıdıgın için teşekkür ederiz!</p>';
$_['text_guest']           = '<p>Siparişiniz başarıyla tarafımıza ulaşmıştır!!</p><p>Herhangi bir sorununuz var ise <a href="%s">Mağaza Müşteri İlişikleri</a>.</p><p>Mağazamızdan alışveriş yaptıgınız için teşekkür ederiz!</p>';