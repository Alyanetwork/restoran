<?php
// Türkçe ye Çeviri osdem66: www.tr-opencart.com
// Heading
$_['heading_title'] = 'Başarısız Ödeme!';

// Text
$_['text_basket']   = 'Alıveriş Sepeti';
$_['text_checkout'] = 'Kasa';
$_['text_failure']  = 'Başarısız Ödeme';
$_['text_message']  = '<p>Ödeme işleminizde bir sorun oldugu için siparişiniz tamamlanamadı.</p>

<p>Olası nedenleri:</p>
<ul>
  <li>Yetersiz Bakiye</li>
  <li>Doğrulama başarısız oldu</li>
</ul>

<p>Farklı bir ödeme yöntemi kullanarak tekrar sipariş deneyebilirsiniz.</p>

<p>Sorun devam ederse, lütfen Bizimle <a href="%s">İletişime</a> Geçiniz sorunlarını en kısa sürede çözüme ulaştırılacaktır.</p>
';
