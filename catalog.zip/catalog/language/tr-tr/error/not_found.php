<?php
// Türkçe ye Çeviri : www.tr-opencart.com



// Heading
$_['heading_title'] = 'Aradığınız Sayfa Bulunamadı! sayfa kaldırılmış yada degiştirilmiş olabilir.';

// Text
$_['text_error']    = 'Aradığınız Sayfa Bulunamadı! sayfa kaldırılmış yada degiştirilmiş olabilir.';
