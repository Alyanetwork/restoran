<?php

// Heading
$_['heading_blog'] = 'Blog';
$_['heading_category_title'] = 'Kategoriler';
$_['heading_search_title']   = 'Arama';
$_['heading_tags_title']     = 'Popüler Etiketler';
$_['heading_popular_title']  = 'Popüler Yazılar';
$_['heading_latest_title']   = 'Son Yazılar';

// Text
$_['text_blog']           = 'Blog';
$_['text_comments']       = 'Yorumlar';
$_['text_posted_by']      = 'Yazar';
$_['text_category']       = 'Kategori';
$_['text_tags']           = 'Etiketler';
$_['text_no_comments']    = 'Henüz yorum yapılmamış';
$_['text_leave_reply']    = 'Yanıtla';
$_['text_required_info']  = 'E-posta adresiniz yayınlanmaz. Zorunlu alanlar işaretlidir.';
$_['text_name']           = 'İsim';
$_['text_email']          = 'E-posta';
$_['text_content']        = 'İçerik';
$_['text_related_products']  = 'İlgili Ürünler';
$_['text_related_articles']  = 'İlgili Yazılar';
$_['text_search']         = 'Armama';
$_['text_enter_keywords'] = 'Kelime yazın';
$_['text_success']        = 'Yorumunuz için teşekkürler';
$_['text_error']            = 'Sonuç yok.';
$_['text_success_approval']         = 'Yorumunuz için teşekkürler. Yönetici onayından sonra yayınlanacaktır.';



// Button
$_['button_read_more']      = 'Devamı';
$_['button_post_comment']   = 'Yorumlar';
$_['button_load_more']      = 'Daha Fazla';

// Error
$_['error_name']               = 'Hata! İsim 3 - 55 karakter aralığında olmalıdır.';
$_['error_email']              = 'Hata! E-posta 3 - 55 karakter aralığında olmalıdır.';
$_['error_email_syntax']       = 'Hata! E-posta geçersiz!';
$_['error_content']            = 'Hata! Mesaj 10 - 1000 karakter aralığında olmalıdır.';


// META
$_['meta_title_default']       = 'Blog - Yazı Listesi';
$_['meta_description_default'] = 'Blog yazı listesi';
$_['meta_keywords_default']    = 'blog,yazılar';
